# Antinomie 0.6.0 host dependency notices

This inventory covers the locked Linux dependency graph and retains upstream
notices. Its verification history does not assert a complete legal review. HOST-DEPENDENCIES.json contains 459 third-party crate
records, their exact Cargo.lock checksums, resolved features, declared license
expressions, selected alternatives and retained notice paths. Non-dev workspace
reachability includes build and procedural-macro dependencies conservatively;
the list is not proof that every listed crate contributes linked executable code.

Each cached published .crate was checked against its Cargo.lock SHA-256. Retained
crate texts were checked byte-for-byte against that archive. When workspace
license texts were omitted from a published subcrate, the shared upstream files
were obtained at its exact .cargo_vcs_info.json Git commit; the manifest retains
the URL, commit and notice digest. MIT/Apache alternatives are selected only when
offered explicitly. Conjunctive Unicode/font obligations and LLVM exceptions
remain intact. Crate metadata shows no selected GPL/LGPL/MPL license, but that
does not relicense the application's embedded kernel patches or public rule data.

Two packages omit a separate upstream copyright/LICENSE text:

- ascii_tree 0.1.1 declares MIT and author d.maetzke@bpressure.net in its published
  package, but includes no license text or VCS record. Its declared GitHub
  repository returned 404 during preparation. No copyright year/holder was invented.
- tinyzip 0.4.0 declares MIT, but no copyright/license text is present in its
  published package or exact upstream tree at 26cdbc441d5db08ac26bfbd7ba23557707d8524a.
  No copyright year/holder was invented.

Their unchanged complete published .crate archives, original Cargo manifests and
README files are retained under upstream-published-packages, alongside the
unchanged canonical SPDX MIT terms. Cargo documents the license field as the
license under which a package is released. The actual source/metadata scan found
no conflicting license or copyright declaration. DECLARED-MIT-PACKAGES.json
records exact checksums, declarations, scan results and canonical-term provenance.
The coordinator accepted this metadata/package/terms arrangement for packaging;
it does not claim to have recovered nonexistent publisher-specific notices.
SPDX template placeholders remain unchanged, and no new grant by Antinomie's
project owner is asserted for either dependency.

hexf-parse 0.2.1 declares CC0-1.0 and author Kang Seonghoon in its published
package. No standalone license text exists in that crate or its exact upstream
tree. Its declaration and unchanged standard CC0 text from the checksum-verified
constant_time_eq 0.4.2 distribution are retained with their provenance.

Rust-Standard-Library-COPYRIGHT.html retains the actual Rust 1.98.1 toolchain's
standard-library inventory, including its third-party terms. BINARY-BOUNDARIES.json
records the initial qualification candidate's digest/build ID, source checkpoint
and required dynamic sonames. It does not claim to identify the final release
executable. The inspected stripped candidate matches its unstripped target by
GNU build ID; the final release is verified separately.
SQLite, libgcc, glibc/libm and the loader are system-provided; no shared library
is copied into the inspected application archive, and libsqlite3-sys's bundled
feature is disabled. Optional TShark, debugger/decompiler tools and Python tools
are not bundled by this archive. A future package that includes them needs a new
component/source review.

Existing font/icon/rule notices are retained under embedded-assets/LICENSES.
The third-party community rule data is included separately, with its original
per-rule author/license/source metadata and all 2,096 YARA attribution records.
The filtered subset is the recorded adaptation; it does not change the individual
rule terms. Apache capa-rules data retains its upstream package license/metadata.
Khronos registry interface headers have their original notices retained separately.
These are upstream/public data and notices, not Antinomie's private Rust source.
The two intact third-party package archives also contain their public upstream
Rust source and tests; no Antinomie host Rust application source is included.

Kernel-source arrangements for the application-embedded build kit and guest bases
remain separate: use the exact revision-16 kernel corresponding-source archive,
bootstrap source archive and desktop source inventory prepared for the release.
Do not label the executable, its embedded data or the guest images wholly MIT.
